Welcome to the Arisu Projekt on github
--------------------------------------

Arisu is an AI desigend to be as cusomizable as possible, while still being as userfriendly as possible.

To find out more and learn how to speak with Arisu at http://arisu.qcoded.de

--------------------------------------

To run arisu on windows, just run the main_windows.py, on Gnu/Linux and Mac osX just run the main.py
