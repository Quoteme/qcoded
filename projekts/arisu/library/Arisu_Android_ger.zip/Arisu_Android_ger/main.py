# Arisu is an open source AI for intelligent interacting with other individuals.
# It uses the GLPv3.
# The file 'brain.htmk' is used to define the words she can say or she already learned.

# Import needed modules
from __future__ import print_function   # import print_functions to write to the brain.
import datetime                         # used to display the time in the log and more
import os                               # import os to use the clear command
import sys                              # for printing on one line
import time                             # for the use of time.sleep
import android                          # android specific commands

#---------------------------------------------------------------------------#
#                              Basic Variables                              #
#---------------------------------------------------------------------------#
# Here are the basic variables defined:
end_Arisu = 'no'; # if end_Arisu = 'yes', then does Arisu end, if it's 'no', it continues.
start = 'yes'; # is 'yes' for the fist loop, then switches to 'no'.
error = 'none'; # The errors are listed in here. They can be used to see problems.
usr_input = ''; # The user input is what Arisu will respond to.
loops_made = 0; # Here are all the loops listed wich were made.
brain_content = ''; # All the content Arisu's Brain stores.
exiting = 'no'; # this is triggered to 'yes', when Arisu stopps.
changed = 'no'; # this counts the changes, aka added questions and answers in a session.
current_dir = 'lang/';
sound = 1;
droid = android.Android()


# personal_info.html doesn't work, so name assignment needs to be hardcoded
perso_name_AIName = 'Arisu';
perso_name = 'Lain';
perso = 'Dieser Informationen sind auf Ihrem Endgeraet nicht verfuegbar'

class text_elements:
    pipe = '--->'; # the pipes are used to display the current stade in the log file.
    pipe_short = '>';
    pipe_block = '|-->';
    pipe_open = '--!';
    pipe_close = '!--';
    pipe_expander = '----'

class text_color: # These are the default colors to choose for the text.
    black = '\033[30m';
    red = '\033[1;31m';
    green = '\033[1;32m';
    yellow = '\033[1;33m';
    blue = '\033[1;34m';
    purple = '\033[1;35m';
    cyan = '\033[1;36m';
    white = '\033[1;37m';
    reset = '\033[m' # Reset restores the default shell-text-color.

class usr: # This class is used to define the colors, which resemble each party.
    arisu = text_color.cyan;
    person = text_color.green;


clear = lambda: os.system('clear') # define the clear command

#---------------------------------------------------------------------------#
#                          General File Read/Write                          #
#---------------------------------------------------------------------------#
#def read_brain():
try:
    # Read mode opens a file for reading only.
    brain_file = open( current_dir + '/' + "brain.html", "r")
    try:
        # Read the entire contents of the brain at once.
        brain = brain_file.read()
        brain_content = brain;
    finally:
        brain_file.close()
except IOError:
    pass

def relode_brain():
    try:
        # Read mode opens a file for reading only.
        brain_file = open( current_dir + '/' + "brain.html", "r")
        try:
            #open brain and brain_content as global variables
            global brain
            global brain_content
            # Read the entire contents of the brain at once.
            brain = brain_file.read()
            brain_content = brain;
        finally:
            brain_file.close()
    except IOError:
        pass


def write_brain(new):
    # Write mode creates a new file or overwrites the existing content of the file.
    # Write mode will _always_ destroy the existing contents of a file.
    try:
        # This will create a new file or **overwrite an existing file**.
        brain_file = open( current_dir + '/' + "brain.html", "w")
        try:
            print( brain_content + '\n' + new , file=brain_file) # Write a string to a file
        finally:
            brain_file.close()
    except IOError:
        pass

def first_log(): # If there is no exsiting log in the logfile, Arisu creates one.
    try:
        # Read mode opens a file for reading only.
        log_file = open("log.html", "r")
        try:
            # Read the entire contend of 'log.html' at once.
            log_read = log_file.read()
            if log_read == '': # If the log.html is empty, will the header be written
                log('# Arisu is a open source AI.')
                log('\n# This Projekt uses the GLPv3')
                log('\n# Make sure to donate.')
                arisu_tutorial();
                
        finally:
            log_file.close()
    except IOError:
        pass

def log(message):
    # Append mode adds to the existing content, e.g. for keeping a log file. Append
    # mode will _never_ harm the existing contents of a file.
    try:
        # This tries to open an existing file but creates a new file if necessary.
        logfile = open("log.html", "a")
        try:
            logfile.write( message )
        finally:
            logfile.close()
    except IOError:
        pass

# here are the personal-info's going to be read
try:
    # Read mode opens a file for reading only.
    person_file = open("person_info.html", "r")
    try:
        # Read the entire contents of the person_info at once.
        perso = person_file.read()

        perso_found = perso.find( 'Name' ) # seeks if/where the name is located in the p.i
        perso_one = perso.find( ':',perso_found ) # seeks the next ':' after the found string (input)
        perso_two = perso.find( ';',perso_one ) # seeks the next ';' after the ':'
        perso_name = perso[ int(perso_one) + 2 : int(perso_two)]
        #calculates the place of the answer

        perso_found_AIName = perso.find( 'AIName' ) # seeks if/where the name is located in the p.i
        perso_one_AIName = perso.find( ':',perso_found_AIName ) # seeks the next ':' after the found string (input)
        perso_two_AIName = perso.find( ';',perso_one_AIName ) # seeks the next ';' after the ':'
        perso_name_AIName = perso[ int(perso_one_AIName) + 2 : int(perso_two_AIName)]

    finally:
        person_file.close()
except IOError:
    pass

#---------------------------------------------------------------------------#
#                             GUI-Interface                                 #
#---------------------------------------------------------------------------#
droid.webViewShow( 'file:///sdcard/sl4a/scripts/Arisu_Android_ger/gui/gui.html' )

#---------------------------------------------------------------------------#
#                                 Output                                    #
#---------------------------------------------------------------------------#

def arisu_say(says): # writes output without brakes
    arisu_outp = says;
    if sound == 1:
        droid.ttsSpeak( says )

    sys.stdout.write( usr.arisu + text_elements.pipe_short + ' ' )
    droid.eventPost('stdout', text_elements.pipe_short + ' ' + says )
    for letter in arisu_outp:
        print(usr.arisu + letter, end="")
        sys.__stdout__.flush()
        if letter == '.':
            time.sleep(0.2)
        elif letter == '!':
            time.sleep(0.2)
        elif letter == '?':
            time.sleep(0.2)
        else:
            time.sleep(0.05)
        
    print();

def arisu_say_fast(says): # The output from Arisu can be easly controled with this function
    print( usr.arisu + text_elements.pipe_short + ' ' + says)
    droid.eventPost('stdout', text_elements.pipe_short + ' ' + says )

def warning(says):
    print (text_color.red + says + text_color.reset)



def arisu_tutorial():
    global AIName;
    arisu_say_fast( 'Willkommen, ich bin' + perso_name_AIName + ', eine Kuenstliche Intelligenz' )
    arisu_say_fast( 'Ich werde dazu entwickelt mich moeglichst Menschlich zu verhalten' )
    arisu_say_fast( 'und Menschen zu unterstuetzen.')
    arisu_say_fast( 'Bitte besuche arisu punkt qcoded punkt de' )
    arisu_say_fast( 'http://arisu.qcoded.de' )

def exit_arisu():
    title = 'Benachrichtigung';
    message = 'Wollen sie Arisu wirklich beenden?';
    droid.dialogCreateAlert(title, message)
    droid.dialogSetPositiveButtonText( 'Ja' )
    droid.dialogSetNegativeButtonText( 'Nein' )
    droid.dialogShow();
    response = droid.dialogGetResponse().result
    return response['which'] in ( 'Yes', 'No' )

#---------------------------------------------------------------------------#
#                              On Startup                                   #
#---------------------------------------------------------------------------#
if start == 'yes': # Detects if this is the start of Arisu, and the logfile should be written
    start = 'no';
    first_log();
    log('\n')
    log('\n' + str(datetime.datetime.now()))
    log('\n{')
    log('\n' + text_elements.pipe + 'Started Arisu');
    
    try:
        give_tutorial
    except NameError:
        give_tutorial = None


    if ( give_tutorial != 'yes' ) and ( give_tutorial != 'y' ) or ( give_tutorial == None ):
        clear()

        #------------------------------------Version--------------------------------#
        Version = '0.0.5 -- alpha -- 06.09.2014. -- Android';

        #everyting started, welcome message are now displayed
        arisu_say_fast( '#------------------------------------------#' )
        arisu_say_fast( 'Arisu Kern erfolgreich geladen')
        arisu_say_fast( Version + '.')
        arisu_say_fast( '#------------------------------------------#' )
        arisu_say('Willkommen!')

#---------------------------------------------------------------------------#
#                                Commands                                   #
#---------------------------------------------------------------------------#

def commands():
    global usr_input;
    if usr_input == '':
        arisu_say( '...')
    elif usr_input == '@sound':
        global sound;
        if sound == 0:
            sound = 1;
            arisu_say( 'Gerausche AN' )
        elif sound == 1:
            sound = 0;
            arisu_say( 'Gerausche AUS' )
    elif usr_input == '@p':
        arisu_say( 'Ihr jetziger ort ist :' )
        arisu_say_fast( current_dir )
    elif usr_input == '@demo':
        arisu_say_fast ( text_elements.pipe_expander + 'Demo-Modus' + text_elements.pipe_expander )
        arisu_say( '\n Hier sind einige bereits vorhandene funktionen, welche Arisu nutzen kann...:')
        arisu_say( 'Buchstabe fuer Buchstabe schreiben.' )
        arisu_say( text_elements.pipe_expander + text_elements.pipe_expander + text_elements.pipe_expander )
        time.sleep(1)
        arisu_say_fast( 'Linie nach Linie schreiben.' )
        arisu_say( text_elements.pipe_expander + text_elements.pipe_expander + text_elements.pipe_expander )
        time.sleep(1)
        arisu_say( 'Das Datum ausgeben: \nEs ist' + time.strftime( '%H %M %S der %D %M %Y' ) )
        arisu_say( text_elements.pipe_expander + text_elements.pipe_expander + text_elements.pipe_expander )
        time.sleep(1)
        arisu_say( 'Die Android Sprachausgaben nutzen:')
        if sound == 0:
            droid.ttsSpeak( 'Hallo, Ich bin Arisu, eine Kuenstliche Intelligenz' )
        arisu_say( '[Hallo, Ich bin Arisu, eine Kuenstliche Intelligenz]' )
        arisu_say_fast ( text_elements.pipe_expander + 'Demo-End' + text_elements.pipe_expander )
    elif usr_input == '@rb':
        try:
            # Read mode opens a file for reading only.
            brain_file_two = open("file:///sdcard/sl4a/scripts/Arisu-master/lang/brain.html", "r")
            try:
                # Read the entire contents of the brain at once.
                brain_two = brain_file_two.read()
                brain_content_two = brain_two;
            finally:
                brain_file_two.close()
        except IOError:
            pass
            arisu_say( brain_content_two )
    else:
        if exiting == 'no':
            
            usr_input_mod = usr_input.replace( '?', '' ) # excludes ? ! and . from
            usr_input_mod = usr_input_mod.replace( '!', '' ) # the search algorythm
            usr_input_mod = usr_input_mod.replace( '.', '' )
            usr_input_mod = usr_input_mod.replace( perso_name_AIName.lower() , '@AI' ) #change AI name to @AI

            # -_-_-_-_-_-_-_- Search Algorythm -_-_-_-_-_-_-_- #

            found = brain_content.find( usr_input_mod ) # seeks if/where the input is located in the brain.html
            # also replace '?' with '' to not inteferer
            answer_one = brain_content.find( ':',found ) # seeks the next ':' after the found string (input)
            answer_two = brain_content.find( ';',answer_one ) # seeks the next ';' after the ':'
            found_string = brain_content[ int(answer_one) + 2 : int(answer_two)]
            #calculates the place of the answer

            # -_-_-_-_-_-_-_- Tag's -_-_-_-_-_-_-_- #

            found_answer = found_string.replace( '@U', perso_name );#User Name
            found_answer = found_answer.replace( '@Date', str(datetime.datetime.now()) )#date
            found_answer = found_answer.replace( '@Brain', brain_content )#whole Brain
            found_answer = found_answer.replace( '@Perso', perso )#whole perso
            found_answer = found_answer.replace( '@br', '\n' )#brake line
            found_answer = found_answer.replace( '@AI', perso_name_AIName )#reload brain
            found_answer = found_answer.replace( '@path', current_dir )#reload brain

            # -_-_-_-_-_-_-_- Tag's with commands-_-_-_-_-_-_-_- #

            # seeking strings in the output starts------->

            seek_mkdir = brain_content.find( '@mkdir', answer_one,answer_two )
            if seek_mkdir != -1: # if 'mkdir' is present in the selected part of the brain.html
                global current_dir;
                current_dir = current_dir + '/' + usr_input; #create new subfolder for new sub brain.html
                check_path = os.path.exists( current_dir );
                if check_path != True:
                    os.mkdir( current_dir )
                new_brain = open ( current_dir + '/' + 'brain.html' , 'a') ## a will append, w will over-write 
                relode_brain();

            found_answer = found_answer.replace( '@mkdir', '' )

            seek_clear = brain_content.find( '@Clear', answer_one,answer_two )
            if seek_clear != -1: # if 'clear' is present in the selected part of the brain.html
                clear();
            found_answer = found_answer.replace( '@Clear', '' ) # 'delete' the '@Clear'

            seek_up = brain_content.find( '@up', answer_one,answer_two )
            found_answer = found_answer.replace( '@up', '' )#brake line
            if seek_up != -1: # if 'mkdir' is present in the selected part of the brain.html
                global current_dir;usr_input = raw_input( usr.person + text_elements.pipe_block + ' ' ).lower()
                current_dir = current_dir[:current_dir.find('/')]
                check_path = os.path.exists( current_dir );
                if check_path != True:
                    warning( 'Error: Upper folder could not be found.\nVar "current_dir" out of filehirachy')
                new_brain = open ( current_dir + '/' + 'brain.html' , 'a') ## a will append, w will over-write 
                relode_brain();

            # seeking strings ends------------------------>

            if found != -1: # if an answer was found
                arisu_say( found_answer )
                # outputs the found string, aka the answer and returns it with
                # @U changed to the user name.
            else:
                # -_-_-_-_-_-_-_- Dialog for not indexed things -_-_-_-_-_-_-_- #
                #if no matching tags were found, i can be added or be seeked for on the web
                arisu_say_fast( 'Satz wurde noch nicht indexiert.\nSoll dieser Satzt nun indexiert werden,\noder nach ihm im Netzt gesucht werden?\n\ny = yes / e = yes, edit the q.; n = no; w = web\n' )
                event = droid.eventWait().result
                add_y_n = event['data']
                if (add_y_n != 'y') and (add_y_n != 'yes') and (add_y_n != 'e') and (add_y_n != 'edit'):
                    arisu_say_fast( 'Ich habe es nicht indexiert.' )
                    if (add_y_n == 'w') or (add_y_n == 'web'):
                        arisu_say( 'Hier ist eine URL welche dir villeicht helfen kann.' )
                        arisu_say( 'http://www.ddg.gg/' + usr_input.replace( ' ', '%20' ) )
                else:
                    arisu_say_fast( 'I\'ll add it...' )
                    questions = ( usr_input + ': ' ).lower()
                    
                    if ( add_y_n == 'e') or ( add_y_n == 'edit'): #if the question should be added
                        arisu_say_fast( 'Was soll die Frage sein??' )
                        event = droid.eventWait().result
                        questions = event['data']
                        questions = str(questions).lower() + ':'

                    arisu_say_fast( 'Bitte gieb eine Antwort ein.' )
                    event = droid.eventWait().result
                    given_answer = event['data']
                    # let the user input the answer. 
                    write_brain(questions + ' ' + given_answer + ';');
                    changed = 'yes';
                    #now Arisu seeks for a '@mkdir'
                    seek_input_mkdir = usr_input.find( '@mkdir' )
                    relode_brain();
                    if seek_input_mkdir != -1: # if 'mkdir' is present in the selected part of the brain.html
                        global current_dir;
                        current_dir = current_dir + '/' + usr_input; #create new subfolder for new sub brain.html
                        check_path = os.path.exists( current_dir );
                        if check_path != True:
                            os.mkdir( current_dir )
                        new_brain = open ( current_dir + '/' + 'brain.html' , 'a') ## a will append, w will over-write 



#---------------------------------------------------------------------------#
#                               Main Loop                                   #
#---------------------------------------------------------------------------#
while end_Arisu == 'no': # This here is the main loop of Arisu and detects, when to stop respond and input. 
    if loops_made == 0:
        log('\n' + text_elements.pipe + 'Started Loop');
    
    event = droid.eventWait().result
    usr_input = event['data']
    
    if (usr_input == 'exit') or (usr_input == 'close') or (usr_input == 'end'):# By entering such a command, Arisu will stop.
        exit_arisu();
        exiting = 'yes';
        end_Arisu = 'yes'; # Exits Arisu

    commands();

    loops_made += 1;
    pass

#---------------------------------------------------------------------------#
#                              When Stopped                                 #
#---------------------------------------------------------------------------#

log( '\n' + text_elements.pipe + 'General information about the conversation' )

log( '\n' + text_elements.pipe_expander + text_elements.pipe + 'Loops Made: ' + str(loops_made))

log( '\n' + text_elements.pipe_expander + text_elements.pipe + 'Changed: ' + str(changed))

if error != 'none': # If there are errors, then will they be in the log.html
    log( '\n' + text_elements.pipe_expander + text_elements.pipe + 'Errors: ' + error )


log('\n' + text_elements.pipe + 'End Arisu...' )
log('\n}')

print( text_color.reset + text_elements.pipe_open + 'Exit successful' + text_elements.pipe_close )
# restore original text color