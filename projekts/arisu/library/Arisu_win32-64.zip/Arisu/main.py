# Arisu is an open source AI for intelligent interacting with other individuals.
# It uses the GLPv3.
# The file 'brain.txt' is used to define the words she can say or she already learned.
# Version: 0.0.2 -- alpha -- 11.06.2014. -- Windows


# Import needed modules
from __future__ import print_function # import print_functions to write to the brain.
import datetime # used to display the time in the log and more
import os # import os to use the clear command

#---------------------------------------------------------------------------#
#                              Basic Variables                              #
#---------------------------------------------------------------------------#
# Here are the basic variables defined:
end_Arisu = 'no'; # if end_Arisu = 'yes', then does Arisu end, if it's 'no', it continues.
start = 'yes'; # is 'yes' for the fist loop, then switches to 'no'.
error = 'none'; # The errors are listed in here. They can be used to see problems.
usr_input = ''; # The user input is what Arisu will respond to.
loops_made = 0; # Here are all the loops listed wich were made.
brain_content = ''; # All the content Arisu's Brain stores.
exiting = 'no'; # this is triggered to 'yes', when Arisu stopps.
changed = 'no'; # this counts the changes, aka added questions and answers in a session.


class text_elements:
    pipe = '--->'; # the pipes are used to display the current stade in the log file.
    pipe_short = '>';
    pipe_block = '|-->';
    pipe_open = '--!';
    pipe_close = '!--';
    pipe_expander = '----'

def clear():
	os.system('cls' if os.name == 'nt' else 'clear')


#---------------------------------------------------------------------------#
#                          General File Read/Write                          #
#---------------------------------------------------------------------------#
#def read_brain():
try:
    # Read mode opens a file for reading only.
    brain_file = open("lang/brain.txt", "r")
    try:
        # Read the entire contents of the brain at once.
        brain = brain_file.read()
        brain_content = brain;
    finally:
        brain_file.close()
except IOError:
    pass

def relode_brain():
    try:
        # Read mode opens a file for reading only.
        brain_file = open("lang/brain.txt", "r")
        try:
            #open brain and brain_content as global variables
            global brain
            global brain_content
            # Read the entire contents of the brain at once.
            brain = brain_file.read()
            brain_content = brain;
        finally:
            brain_file.close()
    except IOError:
        pass


def write_brain(new):
    # Write mode creates a new file or overwrites the existing content of the file.
    # Write mode will _always_ destroy the existing contents of a file.
    try:
        # This will create a new file or **overwrite an existing file**.
        brain_file = open("lang/brain.txt", "w")
        try:
            print( brain_content + '\n' + new , file=brain_file) # Write a string to a file
        finally:
            brain_file.close()
    except IOError:
        pass

def first_log(): # If there is no exsiting log in the logfile, Arisu creates one.
    try:
        # Read mode opens a file for reading only.
        log_file = open("log.txt", "r")
        try:
            # Read the entire contend of 'log.txt' at once.
            log_read = log_file.read()
            if log_read == '': # If the log.txt is empty, will the header be written
                log('# Arisu is a open source Projekt to emulate human behaves.')
                log('\n# Arisu uses the GLPv3')
                log('\n# Make sure to donate to the FSF.')
                arisu_tutorial();
                
        finally:
            log_file.close()
    except IOError:
        pass

def log(message):
    # Append mode adds to the existing content, e.g. for keeping a log file. Append
    # mode will _never_ harm the existing contents of a file.
    try:
        # This tries to open an existing file but creates a new file if necessary.
        logfile = open("log.txt", "a")
        try:
            logfile.write( message )
        finally:
            logfile.close()
    except IOError:
        pass

# here are the personal-info's going to be read
try:
    # Read mode opens a file for reading only.
    person_file = open("person_info.txt", "r")
    try:
        # Read the entire contents of the person_info at once.
        perso = person_file.read()

        perso_found = perso.find( 'Name' ) # seeks if/where the name is located in the p.i
        perso_one = perso.find( ':',perso_found ) # seeks the next ':' after the found string (input)
        perso_two = perso.find( ';',perso_one ) # seeks the next ';' after the ':'
        perso_name = perso[ int(perso_one) + 2 : int(perso_two)]
        #calculates the place of the answer

    finally:
        person_file.close()
except IOError:
    pass

#---------------------------------------------------------------------------#
#                                 Output                                    #
#---------------------------------------------------------------------------#

def arisu_say(says): # The output from Arisu can be easly controled with this function
	print ( text_elements.pipe_short + ' ' + says )

def arisu_tutorial():
    arisu_say( 'Wellcome, I\'m Arisu, a artificial intelligens.' )
    arisu_say( 'I\'m desinged to akt like a Humen, speak like' )
    arisu_say( 'one and help People.')
    arisu_say( 'Would you like me, to give you a quick tutorial?' )
    arisu_say( 'y = yes; n = no')

    give_tutorial = input('').lower;

    if (give_tutorial == 'y') or (give_tutorial == 'yes'):
        arisu_say( 'To use me, just enter something in.' )
        arisu_say( 'You can enter anything, a word, a sentence, or even a command.' )
        arisu_say( 'words can be used instead of sentences, like \'Would you like cheese?\'')
        arisu_say( 'can be shortened to \'Cheese?\'.' )
        give_tutorial = input( 'Press enter...' );
        clear();
        arisu_say( 'I do not acctually care, if you type correctly, or if you use \'?!.\'.' )
        arisu_say( 'Instead I mostly make suggestions for that what you type.' )
        arisu_say( 'This means, it\'s not bad, if you type something false' )
        arisu_say( 'Since I am still in a verry early alpha, do you need to' )
        arisu_say( '\'give me\' some of yourself, like vocabulary, personality,' )
        arisu_say( 'and all that stuff.')
        give_tutorial = input( 'Press enter...' );
        clear();
        arisu_say( 'If you input something new to me, like \'How are you?\' and' )
        arisu_say( 'I say, i do not have it indexed, then can you add it to my vocabulary.' )
        arisu_say( 'Just type, yes or y to clarify you want to add it to me, and write the' )
        arisu_say( 'question-tags (the stuff, which I will later react to.).')
        give_tutorial = input( 'Press enter...' );
        clear();
        arisu_say( 'Split multiple tags with a \',\' and end the last one with a \':\'.' )
        arisu_say( 'Press then enter and continue, to set me an answer to thesw questions.' )
        arisu_say( '!Alert! the answer does not need a specific end, like \';, or :\'' )
        arisu_say( 'You can change your language, by creating a')
        arisu_say( 'new \'brain.txt\' in the /lang/ folder.' )
        give_tutorial = input( 'Press enter...' );
        clear();
        arisu_say( 'The last thing is, that you can use commands like \'brain.txt\' or' )
        arisu_say( '\'date\' to show you some information\n' )
        arisu_say( 'For more information, watch at arisu.qcoded.de' )
        give_tutorial = input( 'Press enter...' );
        clear();

#---------------------------------------------------------------------------#
#                              On Startup                                   #
#---------------------------------------------------------------------------#
if start == 'yes': # Detects if this is the start of Arisu, and the logfile should be written
    start = 'no';
    first_log();
    log('\n')
    log('\n' + str(datetime.datetime.now()))
    log('\n{')
    log('\n' + text_elements.pipe + 'Started Arisu');
    
    try:
        give_tutorial
    except NameError:
        give_tutorial = None


    if ( give_tutorial != 'yes' ) and ( give_tutorial != 'y' ) or ( give_tutorial == None ):
        clear()
        arisu_say('Wellcome!')

#---------------------------------------------------------------------------#
#                                Commands                                   #
#---------------------------------------------------------------------------#

def commands():
    if usr_input == '':
        arisu_say( 'seems like you didn\'t sayed anything...' )
    else:
        if exiting == 'no':
            usr_input_mod = usr_input.replace( '?', '' ) # excludes ? ! and . from
            usr_input_mod = usr_input_mod.replace( '!', '' ) # the search algorythm
            usr_input_mod = usr_input_mod.replace( '.', '' )

            # -_-_-_-_-_-_-_- Search Algorythm -_-_-_-_-_-_-_- #

            found = brain_content.find( usr_input_mod ) # seeks if/where the input is located in the brain.txt
            # also replace '?' with '' to not inteferer
            answer_one = brain_content.find( ':',found ) # seeks the next ':' after the found string (input)
            answer_two = brain_content.find( ';',answer_one ) # seeks the next ';' after the ':'
            found_string = brain_content[ int(answer_one) + 2 : int(answer_two)]
            #calculates the place of the answer

            # -_-_-_-_-_-_-_- Tag's -_-_-_-_-_-_-_- #

            found_answer = found_string.replace( '@U', perso_name );
            found_answer = found_answer.replace( '@Date', str(datetime.datetime.now()) )
            found_answer = found_answer.replace( '@Brain', brain_content )
            found_answer = found_answer.replace( '@Perso', perso )
            found_answer = found_answer.replace( '@br', '\n' )
            found_answer = found_answer.replace( '@rl', 'relode_brain()' )

            seek_clear = brain_content.find( '@Clear', answer_one,answer_two )
            if seek_clear != -1: # if 'clear' is present in the selected part of the brain.txt
                clear();
            found_answer = found_answer.replace( '@Clear', '' ) # 'delete' the '@Clear'

            if found != -1: # if an answer was found
                arisu_say( found_answer )
                # outputs the found string, aka the answer and returns it with
                # @U changed to the user name.
            else:
                # -_-_-_-_-_-_-_- Dialog for not indexed things -_-_-_-_-_-_-_- #
                #if no matching tags were found, i can be added or be seeked for on the web
                arisu_say( 'Seems like I do not have this indexed.' )
                arisu_say( 'Would you like me to add it, or seek on the web?')
                arisu_say( 'y = yes; n = no; w = web\n' )
                add_y_n = input( '' ).lower()
                if (add_y_n != 'y') and (add_y_n != 'yes'):
                    arisu_say( 'I did not add it.' )
                    if (add_y_n == 'w') or (add_y_n == 'web'):
                        arisu_say( 'Here is a link, that might help you.' )
                        arisu_say( 'ddg.gg/' + usr_input.replace( ' ', '%20' ) )
                else:
                    arisu_say( 'I\'ll add it...' )
                    arisu_say( 'What should be the questions? (split them with a \',\').' )
                    arisu_say( 'and make a \':\' at the last one.' )
                    questions = input( usr.person + text_elements.pipe_open + ' ' ).lower()
                    # let the user input the question tags
                    arisu_say( 'Now enter the answer.' )
                    given_answer = input( usr.person + text_elements.pipe_open + ' ' )
                    # let the user input the answer. 
                    write_brain(questions + ' ' + given_answer + ';');
                    changed = 'yes';
                    relode_brain();



#---------------------------------------------------------------------------#
#                               Main Loop                                   #
#---------------------------------------------------------------------------#
while end_Arisu == 'no': # This here is the main loop of Arisu and detects, when to stop respond and input. 
    if loops_made == 0:
        log('\n' + text_elements.pipe + 'Started Loop');
    
    usr_input = input( text_elements.pipe_block + ' ' ).lower()

    if (usr_input == 'exit') or (usr_input == 'close') or (usr_input == 'end'):# By entering such a command, Arisu will stop.
        exiting = 'yes';
        end_Arisu = 'yes'; # Exits Arisu

    commands();

    loops_made += 1;
    pass

#---------------------------------------------------------------------------#
#                              When Stopped                                 #
#---------------------------------------------------------------------------#

log( '\n' + text_elements.pipe + 'General information about the conversation' )

log( '\n' + text_elements.pipe_expander + text_elements.pipe + 'Loops Made: ' + str(loops_made))

log( '\n' + text_elements.pipe_expander + text_elements.pipe + 'Changed: ' + str(changed))

if error != 'none': # If there are errors, then will they be in the log.txt
    log( '\n' + text_elements.pipe_expander + text_elements.pipe + 'Errors: ' + error )


log('\n' + text_elements.pipe + 'End Arisu...' )
log('\n}')

print( text_color.reset + text_elements.pipe_open + 'Exit successful' + text_elements.pipe_close )
# restore original text color