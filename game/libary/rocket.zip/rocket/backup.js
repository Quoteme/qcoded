var version ='0.1.2';
var is_playing = false;
init();
function init()
{
  background_canvas = document.getElementById('background_canvas');
  background_ctx = background_canvas.getContext('2d');
  main_canvas = document.getElementById('main_canvas');
  main_ctx = main_canvas.getContext('2d');
 
  document.addEventListener("keydown", key_down, false);
  document.addEventListener("keyup", key_up, false);
 
  requestaframe = (function() {
                return window.requestAnimationFrame     ||
                  window.webkitRequestAnimationFrame    ||
                  window.mozRequestAnimationFrame       ||
                  window.oRequestAnimationFrame         ||
                  window.msRequestAnimationFrame        ||
                  function (callback) {
                    window.setTimeout(callback, 1000 / 60)
                  };
  })();
 
  player = new Player();
  mothership = new Mothership();
  asteroids = new Array(); //normal enemies (brown) instead of the old enemys
  enemies = new Array();
  bullets = new Array();
  load_media();
  
  buttons_drawX = new Array();
  buttons_drawY = new Array();
  buttons_width = new Array();
  buttons_height = new Array();
  buttons_status = new Array();
  is_menu = true;
  bgcheck = false;
  alertcount = false;
  bg_sprite.addEventListener("load", start_loop, false);
};
function load_media()
{
  bg_sprite = new Image();
  bg_sprite.src = 'images/bg_sprite.png';
  main_sprite = new Image();
  main_sprite.src = 'images/main_sprite.png';
};
function menu()
{
  main_menu_buttons = new Array("New Game", "High Scores", "Options", "Credits", "Games");
  for (var i = 0; i  < main_menu_buttons.length; i++)
  {
    var drawX = 600 / 2 / 2;
    var drawY = 800 / 5 + i * 60;
    var height = 50;
    var width = 200;
    var srcX = 32;
    
    if (buttons_status[i] == undefined)
    {
      buttons_status[i] = "normal";
      buttons_drawX[i] = drawX;
      buttons_drawY[i] = drawY;
      buttons_height[i] = height;
      buttons_width[i] = width;
    }
    
    if (buttons_status[i] == "hover")
    {
      srcX += height;
      width += 200 + 50 + 6;
      
      if (i == 0)
	is_menu = false;
      if (i == 1)
	if (alertcount == true)
	  {
	    alert("Not included yet...");
	    alertcount = false;
	  }
      if (i == 2)
	if (alertcount == true)
	  {
	    alert("nothing set yet");
	    alertcount = false;
	  }
      if (i == 3)
	if (alertcount == true)
	  {
	    alert("Code: Luca Happel\nGraphics: Luca Happel\nThe code is free for all at www.qcoded.de");
	    alertcount = false;
	  }
      if (i == 4)
	if (alertcount == true)
	  {
	    alert("See my other games at http://games.qcoded.de.");
	    alertcount = false;
	  }
    }
    
    main_ctx.drawImage(main_sprite, srcX, 64, 32, 32, drawX, drawY, width, height)
    main_ctx.fillStyle = "black";
    main_ctx.font = "35px Arial";
    main_ctx.textBaseline = 'middle';
    main_ctx.fillText(main_menu_buttons[i], drawX, drawY + height / 2);
  }
    main_ctx.fillStyle = "grey";
    main_ctx.font = "10px Arial";
    main_ctx.textBaseline = 'top';
    main_ctx.fillText(version, 0, 0);
  
  background_ctx.drawImage(bg_sprite, 0, 600, 800, 600, 0, 0, 800, 600);
};
function mouse(e)
{
  var x = e.pageX - document.getElementById('game_object').offsetLeft;
  var y = e.pageY - document.getElementById('game_object').offsetTop;
  for (var i = 0; i < buttons_status.length; i++)
    {
      if (x <= buttons_drawX[i] + buttons_width[i] && x >= buttons_drawX[i] &&
          y <= buttons_drawY[i] + buttons_height[i] && y >= buttons_drawY[i])
      {
        buttons_status[i] = "hover";
	alertcount = true;
      }
      else
        buttons_status[i] = "normal";
    }
 
  document.getElementById('x').innerHTML = x;
  document.getElementById('y').innerHTML = y;
};
 
function Player()
{
  this.life = 100;
  this.drawX = 360;
  this.drawY = 425;
  this.speed = 5;
  this.srcX = 0;
  this.srcY = 0;
  this.width = 32;
  this.hight = 32;
  this.is_downkey = false;
  this.is_upkey = false;
  this.is_leftkey = false;
  this.is_rightkey = false;
  this.is_skey = false;
  this.is_akey = false;
  this.shoot_wait = 20;
  this.shoot_time = this.shoot_wait;
  this.beam = false;
  this.a = false;
};
Player.prototype.draw = function()
{
  if (this.life > 0)
  {
      this.check_keys();
	main_ctx.drawImage(main_sprite, this.srcX, this.srcY, this.width, this.hight, this.drawX, this.drawY,32,32);
	if (this.drawX > 800)
	{
	  this.drawX = -this.width;
	}
	if (this.drawX < 0 - 32)
	{
	  this.drawX = 800;
	}
	if (this.drawY > 600)
	{
	  this.drawY = 599;
	}
	if (this.drawY < 0 - 32)
	{
	  this.drawY = 0;
	}	
  }
  else
  {
    alert("Game Over\nYou already reached Level " + mothership.level + " :)\nRefresh to restart!")
    this.life = 100;
    is_menu = true;
  }
};
Player.prototype.check_keys = function()
{
  if (this.is_downkey == true)
    this.drawY += this.speed;
  if (this.is_upkey == true)
    this.drawY -= this.speed;
  if (this.is_leftkey == true)
    this.drawX -= this.speed;
  if (this.is_rightkey == true)
    this.drawX += this.speed;
  
  if (this.is_skey == true && this.shoot_wait >= this.shoot_time)
  {
    bullets[bullets.length] = new Bullet(this.drawX, this.drawY - this.hight / 2, true);
   this.shoot_wait = 0;
  }else{
    this.shoot_wait++;
  }
  
  if (this.beam == true)
  {
      if (this.is_akey == true)
      {
	this.a = true;
	bullets[bullets.length] = new Bullet(this.drawX, this.drawY - this.hight / 2, true);
      }else{
	this.a = false;
      }
      
  }
};
 
function Mothership()
{
  this.olife = 100;
  this.life = 100;
  this.drawX = Math.round(Math.random()*800);
  this.drawY = Math.round(Math.random()*50);
  this.speed = 1;
  this.srcX = 32;
  this.srcY = 0;
  this.width = 64;
  this.hight = 32;
  this.exploded = false;
  this.wait = 100;
  this.is_dead = false;
  this.shown = false;
  this.level = 1;
};
Mothership.prototype.draw = function()
{
  if (this.is_dead == false)
  {
      this.ai();
      if (this.exploded == false)
	main_ctx.drawImage(main_sprite, this.srcX, this.srcY, this.width, this.hight, this.drawX, this.drawY, 64, 32);
      if (this.life <= 0)
  {  
    if (this.level < 7)
    {
    alert("Congratulations,\nYou defeated the UfO!\nNow you can reach level " + this.level + "!\nYou also found an upgrade, your bullets are now faster!");
      player.shoot_time -= 2;
      player.shoot_wait -= 2;
    }
    if (this.level == 7)
    {
      alert("Congratulations,\nYou defeated the UfO now 10 times!\nNow you can reach level " + this.level + "! This upgrade gives you the beam, use it with the key 'a' !\nSadly, the upgrade toke all the upgrades from your bullets away...");
      player.beam = true;
      player.shoot_time == 15;
      player.shoot_wait == 15;
    }
    if (this.level > 7)
      alert("Well done, you defeated all the enemies.\nBut if you want, you can still fight against them :)");
      this.exploded = true;
      this.is_dead == true;
      this.olife += 100;
      this.level += 1;
      spawn_asteroid(5 * this.level);
      this.life = this.olife;
      this.exploded = false;
  }
  }
};
Mothership.prototype.ai = function()
{
  if (this.exploded == false)
  {
  this.drawX += this.speed;
  if (this.drawX > 800)
    this.drawX = -this.width;
  }
  
  if (this.exploded == false)
   {
    main_ctx.fillStyle = "white";
    main_ctx.font = "10px Arial";
    main_ctx.textBaseline = 'bottom';
    main_ctx.fillText(this.life, this.drawX, this.drawY);
   }
  
  if (this.exploded == true && this.wait > 0)
  {
    main_ctx.drawImage(main_sprite, 32, 32, 32, 32, this.drawX - 16, this.drawY - 16, 96, 96);
    this.wait--;
  }
  if (this.wait < 0)
    this.wait = 100;
  if (this.exploded == false)
 if (Math.round(Math.random()*100) == 50)
 {
    bullets[bullets.length] = new Bullet(this.drawX, this.drawY);
 }
};

 function Bullet(x, y, is_player)
{
  if (is_player == true)
    this.is_player = true;
  else
    this.is_player = false;
  this.drawX = x;
  this.drawY = y;
  this.speed = 4;
  if (this.is_player)
    {
  this.srcX = 64;
  this.srcY = 32;
    }
    else
    {
  this.srcX = 0;
  this.srcY = 64;
    }
  this.width = 32;
  this.height = 32;
  this.exploded = false;
  this.wait = 0;
}
Bullet.prototype.draw = function()
{
  if (this.exploded == false)
  {
    if (this.is_player)
        this.drawY -= this.speed;
      else
        this.drawY += this.speed;
  main_ctx.drawImage(main_sprite, this.srcX, this.srcY, this.width, this.height, this.drawX, this.drawY, 32, 32);
  }
  if (this.is_player == false && this.drawX <= player.drawX + 32 && this.drawX + 32 >= player.drawX &&
      this.drawY <= player.drawY + 32 && this.drawY + 32 >= player.drawY && this.exploded == false)
    {
    player.life -= 10;
    this.exploded = true;
    this.wait = 50;
    }
    
 if (this.is_player == true)
 {
	if (this.drawX <= mothership.drawX + 32 && this.drawX + 32 >= mothership.drawX &&
      this.drawY <= mothership.drawY + 32 && this.drawY + 32 >= mothership.drawY && this.exploded == false)
	{
	  if (mothership.exploded == true)
	  {
	    //nothing
	  }
	  else
	  {
	  this.exploded = true;
	  this.wait = 50;
	  if (player.a == false)
	  mothership.life -= 5;
	  if (player.a == true)
	  mothership.life -= 1;
	  }
	}

      for (var i = 0; i < asteroids.length; i++)
      {
	if (this.drawX <= asteroids[i].drawX + 32 && this.drawX + 32 >= asteroids[i].drawX &&
      this.drawY <= asteroids[i].drawY + 32 && this.drawY + 32 >= asteroids[i].drawY && this.exploded == false)
	{
	  if (asteroids[i].exploded == true)
	  {
	    //nothing
	  }
	  else
	  {
	  this.exploded = true;
	  this.wait = 50;
	  this.exploded = true;
	  this.wait = 50;
	  if (player.a == false)
	  asteroids[i].life -= 5;
	  if (player.a == true)
	  asteroids[i].life -= 1;
	  }
	}
      }
 } 
  if (this.exploded == true && this.wait > 0)
    main_ctx.drawImage(main_sprite, 32, 32, this.width, this.height,this.drawX, this.drawY, 32,32);
    this.wait--;
  
};

function Asteroid()
{
  this.life = 20;
  this.drawX = Math.round(Math.random()*800);
  this.drawY = Math.round(Math.random()*300 + 150);
  this.speed = Math.round(Math.random()*2 + 1);
  this.srcX = 0;
  this.srcY = 32;
  this.width = 32;
  this.hight = 32;
  this.exploded = false;
  this.wait = 100;
  this.is_dead = false;
};
Asteroid.prototype.draw = function()
{
  if (this.is_dead == false)
    {
  
  this.ai();
  if (this.exploded == false)
  {
    main_ctx.drawImage(main_sprite, this.srcX, this.srcY, this.width, this.hight, this.drawX, this.drawY,32,32);
    this.drawY += this.speed;
  }
 
  if (this.drawX <= player.drawX + 32 && this.drawX + 32 >= player.drawX &&
      this.drawY <= player.drawY + 32 && this.drawY + 32 >= player.drawY && this.exploded == false)
    {
    this.exploded = true;
    player.life -= 1;
    spawn_asteroid(2);
    }
   
   if (this.life <= 0)
   {
      this.exploded = true;
      this.is_dead == true;
    }
   
   
   if (this.exploded == false)
   {
    main_ctx.fillStyle = "white";
    main_ctx.font = "10px Arial";
    main_ctx.textBaseline = 'bottom';
    main_ctx.fillText(this.life, this.drawX, this.drawY);
   }
  
  if (this.exploded == true && this.wait > 0)
  {
    main_ctx.drawImage(main_sprite, 32, 32, 32, 32, this.drawX - 8, this.drawY - 8, 48, 48);
    this.wait--;
  }
  if (this.wait < 0)
    this.wait = 100;
    }
  
};
Asteroid.prototype.ai = function()
{
  
  //if (this.exploded == false) //Here is additional speed for the asteroid, this also causes, that the asteroid does not get stopped, just slowed down.
  this.drawY += 1;
  
  if (this.drawY > 600)
    this.drawY = -this.width;
}
function spawn_asteroid(n)
{
  for (var i = 0; i < n; i++)
  {
    asteroids[asteroids.length] = new Asteroid();
  }
}

function loop()
{

  if (is_menu == false)
  {
  main_ctx.clearRect(0,0,800,600);
  if (bgcheck == true)
  {
    background_ctx.drawImage(bg_sprite, 0, 0);
    bgcheck = false;
  }
 mothership.draw();
 for (var i = 0; i < asteroids.length; i++)
  {
    asteroids[i].draw();
  }
  for (var i = 0; i < bullets.length; i++)
  {
    bullets[i].draw();
  }
  main_ctx.fillStyle = "white";
  main_ctx.font = "20px Arial";
  main_ctx.textBaseline = 'top';
  main_ctx.fillText(player.life, 0, 0);
  player.draw();
  if (mothership.life <= 0 && player.life == 100)
  {
    
    alert("archievement got: shot 'em up!");
    mothership.shown = true;
  }
  }else
    menu();
  if (is_playing)
    requestaframe(loop);
}
function start_loop()
{
  is_playing = true;
  loop();
  background_ctx.drawImage(bg_sprite, 0, 0);
  spawn_asteroid(5);
  bgcheck = true;
}
function stop_loop()
{
  is_playing = false;
}

function key_down(e)
{
  var key_id = e.keyCode || e.which;
  if (key_id == 40) //down key
  {
    player.is_downkey = true;
    e.preventDefault();
  }
  if (key_id == 38) //up key
  {
    player.is_upkey = true;
    e.preventDefault();
  }
  if (key_id == 37) //left key
  {
    player.is_leftkey = true;
    e.preventDefault();
  }
  if (key_id == 39) //right key
  {
    player.is_rightkey = true;
    e.preventDefault();
  }
  if (key_id == 83) //s key
  {
    player.is_skey = true;
    e.preventDefault();
  }
  if (key_id == 65) //a key
  {
    player.is_akey = true;
    e.preventDefault();
  }
}
function key_up(e)
{
  var key_id = e.keyCode || e.which;
  if (key_id == 40) //down key
  {
    player.is_downkey = false;
    e.preventDefault();
  }
  if (key_id == 38) //up key
  {
    player.is_upkey = false;
    e.preventDefault();
  }
  if (key_id == 37) //left key
  {
    player.is_leftkey = false;
    e.preventDefault();
  }
  if (key_id == 39) //right key
  {
    player.is_rightkey = false;
    e.preventDefault();
  }
  if (key_id == 83) //s key
  {
    player.is_skey = false;
    e.preventDefault();
  }
  if (key_id == 65) //a key
  {
    player.is_akey = false;
    e.preventDefault();
  }
}