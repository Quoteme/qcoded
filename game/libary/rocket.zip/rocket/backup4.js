var version ='0.0.5';
var is_playing = false;
init();
function init()
{
  background_canvas = document.getElementById('background_canvas');
  background_ctx = background_canvas.getContext('2d');
  main_canvas = document.getElementById('main_canvas');
  main_ctx = main_canvas.getContext('2d');
 
  document.addEventListener("keydown", key_down, false);
  document.addEventListener("keyup", key_up, false);
 
  requestaframe = (function() {
                return window.requestAnimationFrame     ||
                  window.webkitRequestAnimationFrame    ||
                  window.mozRequestAnimationFrame       ||
                  window.oRequestAnimationFrame         ||
                  window.msRequestAnimationFrame        ||
                  function (callback) {
                    window.setTimeout(callback, 1000 / 60)
                  };
  })();
 
  player = new Player();
  mothership = new Mothership();
  asteroids = new Array(); //normal enemies (brown) instead of the old enemys
  enemies = new Array();
  bullets = new Array();
  load_media();
}
function load_media()
{
  bg_sprite = new Image();
  bg_sprite.src = 'images/bg_sprite.png';
  main_sprite = new Image();
  main_sprite.src = 'images/main_sprite.png';
}
function mouse(e)
{
  var x = e.pageX - document.getElementById('game_object').offsetLeft;
  var y = e.pageY - document.getElementById('game_object').offsetTop;
  document.getElementById('x').innerHTML = x;
  document.getElementById('y').innerHTML = y;
}
 
function Player()
{
  this.drawX = 360;
  this.drawY = 425;
  this.speed = 5;
  this.srcX = 0;
  this.srcY = 0;
  this.width = 32;
  this.hight = 32;
  this.is_downkey = false;
  this.is_upkey = false;
  this.is_leftkey = false;
  this.is_rightkey = false;
}
Player.prototype.draw = function()
{
  this.check_keys();
    main_ctx.drawImage(main_sprite, this.srcX, this.srcY, this.width, this.hight, this.drawX, this.drawY,32,32);
    if (this.drawX > 800)
    {
      this.drawX = -this.width;
    }
    if (this.drawX < 0 - 32)
    {
      this.drawX = 800;
    }
    if (this.drawY > 600)
    {
      this.drawY = 599;
    }
    if (this.drawY < 0 - 32)
    {
      this.drawY = 0;
    }
    
};
Player.prototype.check_keys = function()
{
  if (this.is_downkey == true)
    this.drawY += this.speed;
  if (this.is_upkey == true)
    this.drawY -= this.speed;
  if (this.is_leftkey == true)
    this.drawX -= this.speed;
  if (this.is_rightkey == true)
    this.drawX += this.speed;
}
 
function Mothership()
{
  this.drawX = Math.round(Math.random()*800);
  this.drawY = Math.round(Math.random()*50);
  this.speed = 1;
  this.srcX = 32;
  this.srcY = 0;
  this.width = 64;
  this.hight = 32;
}
Mothership.prototype.draw = function()
{
  this.ai();
    main_ctx.drawImage(main_sprite, this.srcX, this.srcY, this.width, this.hight, this.drawX, this.drawY, 64, 32);
};
Mothership.prototype.ai = function()
{
  this.drawX += this.speed;
  if (this.drawX > 800)
    this.drawX = -this.width;
  
 if (Math.round(Math.random()*100) == 50)
 {
    bullets[bullets.length] = new Bullet(this.drawX, this.drawY);
 }
};

 function Bullet(x, y)
{
  this.drawX = x;
  this.drawY = y;
  this.speed = 4;
  this.srcX = 0;
  this.srcY = 64;
  this.width = 32;
  this.height = 32;
  this.exploded = false;
}
Bullet.prototype.draw = function()
{
  main_ctx.drawImage(main_sprite, this.srcX, this.srcY, this.width, this.height, this.drawX, this.drawY, 32, 32);
  this.drawY += this.speed;
 if (this.drawX <= player.drawX + 32 && this.drawX + 32 >= player.drawX &&
      this.drawY <= player.drawY + 32 && this.drawY + 32 >= player.drawY)
    this.exploded = true;
  else
    this.exploded = false;
 
  if (this.exploded == true)
    main_ctx.drawImage(main_sprite, 32, 32, this.width, this.height,this.drawX, this.drawY, 32,32);
};

function Asteroid()
{
  this.drawX = Math.round(Math.random()*800);
  this.drawY = Math.round(Math.random()*300 + 150);
  this.speed = Math.round(Math.random()*2 + 1);
  this.srcX = 0;
  this.srcY = 32;
  this.width = 32;
  this.hight = 32;
  this.exploded = true;
}
Asteroid.prototype.draw = function()
{
  this.ai();
    main_ctx.drawImage(main_sprite, this.srcX, this.srcY, this.width, this.hight, this.drawX, this.drawY,32,32);
    
    this.drawY += this.speed;
 
  if (this.drawX <= player.drawX + 32 && this.drawX + 32 >= player.drawX &&
      this.drawY <= player.drawY + 32 && this.drawY + 32 >= player.drawY)
    this.exploded = true;
  else
    this.exploded = false;
 
  if (this.exploded == true)
    main_ctx.drawImage(main_sprite, 32, 32, 32, 32, this.drawX - 8, this.drawY - 8, 48, 48);
};
Asteroid.prototype.ai = function()
{
  this.drawY += this.speed;
  if (this.drawY > 600)
    this.drawY = -this.width;
}
function spawn_asteroid(n)
{
  for (var i = 0; i < n; i++)
  {
    asteroids[asteroids.length] = new Asteroid();
  }
}

function loop()
{
  main_ctx.clearRect(0,0,800,600);
 
  player.draw();
 mothership.draw();
 for (var i = 0; i < asteroids.length; i++)
  {
    asteroids[i].draw();
  }
  for (var i = 0; i < bullets.length; i++)
  {
    bullets[i].draw();
  }
 
  if (is_playing)
    requestaframe(loop);
}
function start_loop()
{
  is_playing = true;
  loop();
  background_ctx.drawImage(bg_sprite, 0, 0);
  spawn_asteroid(5);
}
function stop_loop()
{
  is_playing = false;
}
 
 
function key_down(e)
{
  var key_id = e.keyCode || e.which;
  if (key_id == 40) //down key
  {
    player.is_downkey = true;
    e.preventDefault();
  }
  if (key_id == 38) //up key
  {
    player.is_upkey = true;
    e.preventDefault();
  }
  if (key_id == 37) //left key
  {
    player.is_leftkey = true;
    e.preventDefault();
  }
  if (key_id == 39) //right key
  {
    player.is_rightkey = true;
    e.preventDefault();
  }
}
function key_up(e)
{
  var key_id = e.keyCode || e.which;
  if (key_id == 40) //down key
  {
    player.is_downkey = false;
    e.preventDefault();
  }
  if (key_id == 38) //up key
  {
    player.is_upkey = false;
    e.preventDefault();
  }
  if (key_id == 37) //left key
  {
    player.is_leftkey = false;
    e.preventDefault();
  }
  if (key_id == 39) //right key
  {
    player.is_rightkey = false;
    e.preventDefault();
  }
}